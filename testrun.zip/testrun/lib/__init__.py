import sys
sys.path.append("..")
from config import *