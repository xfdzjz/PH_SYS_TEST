sourcemeter = {"tcp_addr":"TCPIP0::172.16.60.100::INSTR"}
powersupply = {"port":"COM4","baudRate": 9600}
multimeter = {}
oscilloscope = {"tcp_addr":"TCPIP::172.16.60.164::inst0::INSTR"}
tester = {"port": "COM6", "baudRate": 9600}
