
title = "VDD稳定性测试"

desc = '''
    在时钟trim后做此项测试
'''

def test(ctx):
    '''
    ctx为测试上下文对象，包含初始化好的各测试仪表
    ctx.sourcemeter 未使用
    ctx.multimeter 未使用
    '''
    # 芯片上电VCC=3V
    ctx.powersupply.voltageOutput(3000)
    # TODO:启动示波器检测
    # ctx.oscilloscope.XXX
    # 启动测试
    ctx.tester.runCommand("...")
    # TODO: 观测VDD端口电压值是否低于1.35V，POR信号是否始终保持为高电平，芯片功能是否正常
    return False