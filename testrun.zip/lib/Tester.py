import serial

class Tester:
    def __init__(self, config):
        # self.port = serial.Serial(config["port"], config["baudRate"])
        pass

    def stopAll(self):
        # 复位到待接线状态
        pass

    def runCommand(self, cmd):
        # self.port.write(cmd)
        # self.port.write(0)
        pass

    def waitResponse(self):
        pass

if __name__ == "__main__":
    # Unit test
    t = Tester({"port": "COM1", "baudRate": 115200})
    print("do some unittest")
    input("Press ENTER to continue")
    print("do some unittest")
    print("PASS")