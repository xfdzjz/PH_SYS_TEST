class PowerSupply:
    def __init__(self, config):
        self.config = config

    def stopAll(self):
        # 复位到待接线状态
        self.voltageOutput(0)
        pass

    def voltageOutput(self, mV):
        pass        

if __name__ == "__main__":
    # Unit test
    ps = PowerSupply({})
    print("do some unittest")
    input("Press ENTER to continue")
    print("do some unittest")
    print("PASS")