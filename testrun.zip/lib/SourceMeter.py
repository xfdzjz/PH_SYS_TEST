class SourceMeter:
    def __init__(self, config):
        self.config = config

    def stopAll(self):
        # 复位到待接线状态
        pass

    def voltageOutput(self, mV):
        pass

    def currentOutput(self, mA):
        pass
    
if __name__ == "__main__":
    # Unit test
    m = SourceMeter({})
    print("do some unittest")
    input("Press ENTER to continue")
    print("do some unittest")
    print("PASS")