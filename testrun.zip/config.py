sourcemeter = {}
powersupply = {}
multimeter = {}
oscilloscope = {}
tester = {"port": "COM1", "baudRate": 115200}